git init
git add .
git config user.email "jb7008@ship.edu"
git config user.name "Josh Booth"
git commit -m "first commit"
git remote add origin https://github.com/jb7008/hw2.git
git push -u origin master
